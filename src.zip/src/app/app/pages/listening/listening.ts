import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-listening',
  imports: [],
  templateUrl: './listening.html',
  styleUrl: './listening.css'
})
export class Listening {

}
